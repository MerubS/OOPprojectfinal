﻿namespace Foodie_menu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.minimize_button = new System.Windows.Forms.PictureBox();
            this.close_button = new System.Windows.Forms.PictureBox();
            this.cart_button = new System.Windows.Forms.PictureBox();
            this.slide_panel = new System.Windows.Forms.Panel();
            this.review_button = new System.Windows.Forms.Button();
            this.favorites_button = new System.Windows.Forms.Button();
            this.homeFood_button = new System.Windows.Forms.Button();
            this.exclusive_button = new System.Windows.Forms.Button();
            this.home_button = new System.Windows.Forms.Button();
            this.favorite11 = new Foodie_menu.favorite1();
            this.home1 = new Foodie_menu.home1();
            this.home11 = new Foodie_menu.home1();
            this.review11 = new Foodie_menu.review1();
            this.homeFood1 = new Foodie_menu.homeFood1();
            this.cart1 = new Foodie_menu.cart1();
            this.exclusive1 = new Foodie_menu.exclusive1();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimize_button)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.close_button)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cart_button)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.Color.Gold;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.minimize_button);
            this.panel1.Controls.Add(this.close_button);
            this.panel1.Controls.Add(this.cart_button);
            this.panel1.Controls.Add(this.slide_panel);
            this.panel1.Controls.Add(this.review_button);
            this.panel1.Controls.Add(this.favorites_button);
            this.panel1.Controls.Add(this.homeFood_button);
            this.panel1.Controls.Add(this.exclusive_button);
            this.panel1.Controls.Add(this.home_button);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(941, 67);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Foodie_menu.Resource1.delivery_24px2;
            this.pictureBox1.Location = new System.Drawing.Point(833, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(52, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // minimize_button
            // 
            this.minimize_button.BackColor = System.Drawing.Color.Gold;
            this.minimize_button.Image = global::Foodie_menu.Resource1.minimize;
            this.minimize_button.Location = new System.Drawing.Point(903, 0);
            this.minimize_button.Margin = new System.Windows.Forms.Padding(0);
            this.minimize_button.Name = "minimize_button";
            this.minimize_button.Size = new System.Drawing.Size(19, 19);
            this.minimize_button.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.minimize_button.TabIndex = 7;
            this.minimize_button.TabStop = false;
            this.minimize_button.Click += new System.EventHandler(this.minimize_button_Click);
            // 
            // close_button
            // 
            this.close_button.BackColor = System.Drawing.Color.Gold;
            this.close_button.Image = global::Foodie_menu.Resource1.close;
            this.close_button.Location = new System.Drawing.Point(922, 0);
            this.close_button.Margin = new System.Windows.Forms.Padding(0);
            this.close_button.Name = "close_button";
            this.close_button.Size = new System.Drawing.Size(19, 19);
            this.close_button.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.close_button.TabIndex = 7;
            this.close_button.TabStop = false;
            this.close_button.Click += new System.EventHandler(this.close_button_Click);
            // 
            // cart_button
            // 
            this.cart_button.Image = global::Foodie_menu.Resource1.cart1;
            this.cart_button.Location = new System.Drawing.Point(789, 21);
            this.cart_button.Name = "cart_button";
            this.cart_button.Size = new System.Drawing.Size(47, 43);
            this.cart_button.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.cart_button.TabIndex = 5;
            this.cart_button.TabStop = false;
            this.cart_button.Click += new System.EventHandler(this.cart_button_Click);
            // 
            // slide_panel
            // 
            this.slide_panel.BackColor = System.Drawing.Color.White;
            this.slide_panel.Location = new System.Drawing.Point(0, 0);
            this.slide_panel.Name = "slide_panel";
            this.slide_panel.Size = new System.Drawing.Size(115, 6);
            this.slide_panel.TabIndex = 1;
            // 
            // review_button
            // 
            this.review_button.BackColor = System.Drawing.Color.Gold;
            this.review_button.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.review_button.FlatAppearance.BorderSize = 0;
            this.review_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.review_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.review_button.ForeColor = System.Drawing.Color.White;
            this.review_button.Image = global::Foodie_menu.Resource1.inspection;
            this.review_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.review_button.Location = new System.Drawing.Point(542, 0);
            this.review_button.Name = "review_button";
            this.review_button.Size = new System.Drawing.Size(98, 64);
            this.review_button.TabIndex = 4;
            this.review_button.Text = "Review";
            this.review_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.review_button.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.review_button.UseVisualStyleBackColor = false;
            this.review_button.Click += new System.EventHandler(this.button5_Click);
            // 
            // favorites_button
            // 
            this.favorites_button.BackColor = System.Drawing.Color.Gold;
            this.favorites_button.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.favorites_button.FlatAppearance.BorderSize = 0;
            this.favorites_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.favorites_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.favorites_button.ForeColor = System.Drawing.Color.White;
            this.favorites_button.Image = global::Foodie_menu.Resource1.star;
            this.favorites_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.favorites_button.Location = new System.Drawing.Point(406, 0);
            this.favorites_button.Name = "favorites_button";
            this.favorites_button.Size = new System.Drawing.Size(130, 64);
            this.favorites_button.TabIndex = 3;
            this.favorites_button.Text = "  Favorites";
            this.favorites_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.favorites_button.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.favorites_button.UseVisualStyleBackColor = false;
            this.favorites_button.Click += new System.EventHandler(this.button4_Click);
            // 
            // homeFood_button
            // 
            this.homeFood_button.BackColor = System.Drawing.Color.Gold;
            this.homeFood_button.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.homeFood_button.FlatAppearance.BorderSize = 0;
            this.homeFood_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.homeFood_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeFood_button.ForeColor = System.Drawing.Color.White;
            this.homeFood_button.Image = global::Foodie_menu.Resource1.homemade;
            this.homeFood_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.homeFood_button.Location = new System.Drawing.Point(240, 0);
            this.homeFood_button.Name = "homeFood_button";
            this.homeFood_button.Size = new System.Drawing.Size(160, 64);
            this.homeFood_button.TabIndex = 2;
            this.homeFood_button.Text = "    Home Made";
            this.homeFood_button.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.homeFood_button.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.homeFood_button.UseVisualStyleBackColor = false;
            this.homeFood_button.Click += new System.EventHandler(this.button3_Click);
            // 
            // exclusive_button
            // 
            this.exclusive_button.BackColor = System.Drawing.Color.Gold;
            this.exclusive_button.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.exclusive_button.FlatAppearance.BorderSize = 0;
            this.exclusive_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exclusive_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exclusive_button.ForeColor = System.Drawing.Color.White;
            this.exclusive_button.Image = global::Foodie_menu.Resource1.membership;
            this.exclusive_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.exclusive_button.Location = new System.Drawing.Point(121, 0);
            this.exclusive_button.Name = "exclusive_button";
            this.exclusive_button.Size = new System.Drawing.Size(134, 64);
            this.exclusive_button.TabIndex = 1;
            this.exclusive_button.Text = "    Exclusives";
            this.exclusive_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.exclusive_button.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.exclusive_button.UseVisualStyleBackColor = false;
            this.exclusive_button.Click += new System.EventHandler(this.button2_Click);
            // 
            // home_button
            // 
            this.home_button.BackColor = System.Drawing.Color.Gold;
            this.home_button.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.home_button.FlatAppearance.BorderSize = 0;
            this.home_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.home_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.home_button.ForeColor = System.Drawing.Color.White;
            this.home_button.Image = global::Foodie_menu.Resource1.homem2;
            this.home_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.home_button.Location = new System.Drawing.Point(0, 0);
            this.home_button.Name = "home_button";
            this.home_button.Size = new System.Drawing.Size(115, 64);
            this.home_button.TabIndex = 0;
            this.home_button.Text = "  Home";
            this.home_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.home_button.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.home_button.UseVisualStyleBackColor = false;
            this.home_button.Click += new System.EventHandler(this.button1_Click);
            // 
            // favorite11
            // 
            this.favorite11.BackColor = System.Drawing.Color.White;
            this.favorite11.Location = new System.Drawing.Point(0, 64);
            this.favorite11.Name = "favorite11";
            this.favorite11.Size = new System.Drawing.Size(941, 475);
            this.favorite11.TabIndex = 8;
            this.favorite11.Load += new System.EventHandler(this.favorite11_Load_1);
            // 
            // home1
            // 
            this.home1.BackColor = System.Drawing.Color.White;
            this.home1.Location = new System.Drawing.Point(0, 73);
            this.home1.Name = "home1";
            this.home1.Size = new System.Drawing.Size(941, 466);
            this.home1.TabIndex = 1;
            // 
            // home11
            // 
            this.home11.BackColor = System.Drawing.Color.White;
            this.home11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.home11.Location = new System.Drawing.Point(0, 0);
            this.home11.Name = "home11";
            this.home11.Size = new System.Drawing.Size(941, 539);
            this.home11.TabIndex = 7;
            // 
            // review11
            // 
            this.review11.BackColor = System.Drawing.Color.LavenderBlush;
            this.review11.Location = new System.Drawing.Point(0, 64);
            this.review11.Name = "review11";
            this.review11.Size = new System.Drawing.Size(941, 475);
            this.review11.TabIndex = 6;
            this.review11.Load += new System.EventHandler(this.review11_Load);
            // 
            // homeFood1
            // 
            this.homeFood1.AutoScroll = true;
            this.homeFood1.Location = new System.Drawing.Point(0, 64);
            this.homeFood1.Name = "homeFood1";
            this.homeFood1.Size = new System.Drawing.Size(941, 475);
            this.homeFood1.TabIndex = 4;
            // 
            // cart1
            // 
            this.cart1.BackColor = System.Drawing.Color.White;
            this.cart1.Location = new System.Drawing.Point(710, 64);
            this.cart1.Name = "cart1";
            this.cart1.Size = new System.Drawing.Size(234, 475);
            this.cart1.TabIndex = 3;
            // 
            // exclusive1
            // 
            this.exclusive1.AutoScroll = true;
            this.exclusive1.Location = new System.Drawing.Point(0, 64);
            this.exclusive1.Name = "exclusive1";
            this.exclusive1.Size = new System.Drawing.Size(941, 475);
            this.exclusive1.TabIndex = 2;
            this.exclusive1.Load += new System.EventHandler(this.exclusive1_Load);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(941, 539);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.review11);
            this.Controls.Add(this.homeFood1);
            this.Controls.Add(this.cart1);
            this.Controls.Add(this.exclusive1);
            this.Controls.Add(this.favorite11);
            this.Controls.Add(this.home1);
            this.Controls.Add(this.home11);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimize_button)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.close_button)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cart_button)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button review_button;
        private System.Windows.Forms.Button favorites_button;
        private System.Windows.Forms.Button homeFood_button;
        private System.Windows.Forms.Button exclusive_button;
        private System.Windows.Forms.Button home_button;
        private System.Windows.Forms.Panel slide_panel;
        private home1 home1;
        private exclusive1 exclusive1;
        private System.Windows.Forms.PictureBox cart_button;
        private cart1 cart1;
        private homeFood1 homeFood1;
        private review1 review11;
        private System.Windows.Forms.PictureBox close_button;
        private System.Windows.Forms.PictureBox minimize_button;
        private home1 home11;
        private favorite1 favorite11;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

