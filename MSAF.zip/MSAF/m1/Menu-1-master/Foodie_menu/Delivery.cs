﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class Delivery : Form
    {
        public Delivery()
        {
            InitializeComponent();
        }

        private void listareas_SelectedIndexChanged(object sender, EventArgs e)
        {
            string text = listareas.GetItemText(listareas.SelectedItems);
            MessageBox.Show("Kindly select delivery Option");
        }

        private void buttonsubmit_Click(object sender, EventArgs e)
        {
            string name = txtname.Text;
            string address = txtaddress.Text;
            string phonenumber = txtphone.Text;
            MessageBox.Show(name + " \n " + address + " \n " + phonenumber);
        }
    }
}
