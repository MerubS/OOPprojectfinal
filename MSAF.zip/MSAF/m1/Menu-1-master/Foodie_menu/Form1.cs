﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            myCart obj = new myCart();
            obj.review_updater();
            exclusive1.BringToFront();
            exclusive1.work();
            movePanel(exclusive_button);

            /// Temporary 
        }



        public void movePanel(Control btn)
        {
            slide_panel.Width = btn.Width;
            slide_panel.Left = btn.Left;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            //myCart obj = new myCart();
            //obj.review_updater();
            //exclusive1.BringToFront();
            //exclusive1.work();
           // movePanel(exclusive_button);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            movePanel(home_button);

            this.Hide();
            Form2 f2 = new Form2();
            f2.Show();
            myCart c = new myCart();
            c.savingData();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            movePanel(exclusive_button);
            exclusive1.BringToFront();
            exclusive1.work();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            movePanel(homeFood_button);
            homeFood1.BringToFront();
            homeFood1.work();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            movePanel(favorites_button);
            favorite11.BringToFront();
            favorite11.work();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            movePanel(review_button);
            review11.BringToFront();
            review11.work();
        }

        private void cart_button_Click(object sender, EventArgs e)
        {
            cart1.BringToFront();
            cart1.work();

        }

        private void close_button_Click(object sender, EventArgs e)
        {
            myCart obj = new myCart();
            obj.savingData();
            Application.Exit();
        }

        private void minimize_button_Click(object sender, EventArgs e)
        {
            if (this.WindowState != FormWindowState.Minimized)
                this.WindowState = FormWindowState.Minimized;
        }

       
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void exclusive1_Load(object sender, EventArgs e)
        {

        }

        private void favorite11_Load(object sender, EventArgs e)
        {

        }

        private void selectRestaurant12_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            CR c = new CR();
            c.Show();
        }

        private void favorite11_Load_1(object sender, EventArgs e)
        {

        }

        private void review11_Load(object sender, EventArgs e)
        {

        }
    }
}
