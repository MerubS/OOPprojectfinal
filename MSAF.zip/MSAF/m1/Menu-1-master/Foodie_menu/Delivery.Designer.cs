﻿namespace Foodie_menu
{
    partial class Delivery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.listareas = new System.Windows.Forms.ListBox();
            this.rdcreditcard = new System.Windows.Forms.RadioButton();
            this.phonenumber = new System.Windows.Forms.Label();
            this.rdcashondelivery = new System.Windows.Forms.RadioButton();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.ADDRESSLABEL = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.buttonsubmit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtphone);
            this.groupBox1.Controls.Add(this.listareas);
            this.groupBox1.Controls.Add(this.rdcreditcard);
            this.groupBox1.Controls.Add(this.phonenumber);
            this.groupBox1.Controls.Add(this.rdcashondelivery);
            this.groupBox1.Controls.Add(this.txtaddress);
            this.groupBox1.Controls.Add(this.txtname);
            this.groupBox1.Controls.Add(this.ADDRESSLABEL);
            this.groupBox1.Controls.Add(this.namelabel);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Gold;
            this.groupBox1.Location = new System.Drawing.Point(12, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(595, 226);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Details for delivery";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Location = new System.Drawing.Point(406, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "AREA";
            // 
            // txtphone
            // 
            this.txtphone.Location = new System.Drawing.Point(128, 112);
            this.txtphone.Multiline = true;
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(186, 20);
            this.txtphone.TabIndex = 6;
            // 
            // listareas
            // 
            this.listareas.FormattingEnabled = true;
            this.listareas.ItemHeight = 17;
            this.listareas.Items.AddRange(new object[] {
            "Garden East",
            "Lyari Town",
            "Nazimabad",
            "Gulshan",
            "Saddar Town"});
            this.listareas.Location = new System.Drawing.Point(409, 43);
            this.listareas.Name = "listareas";
            this.listareas.Size = new System.Drawing.Size(125, 89);
            this.listareas.TabIndex = 1;
            this.listareas.SelectedIndexChanged += new System.EventHandler(this.listareas_SelectedIndexChanged);
            // 
            // rdcreditcard
            // 
            this.rdcreditcard.AutoSize = true;
            this.rdcreditcard.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdcreditcard.Location = new System.Drawing.Point(90, 188);
            this.rdcreditcard.Name = "rdcreditcard";
            this.rdcreditcard.Size = new System.Drawing.Size(142, 21);
            this.rdcreditcard.TabIndex = 3;
            this.rdcreditcard.TabStop = true;
            this.rdcreditcard.Text = "Pay via Credit Card";
            this.rdcreditcard.UseVisualStyleBackColor = true;
            // 
            // phonenumber
            // 
            this.phonenumber.AutoSize = true;
            this.phonenumber.Location = new System.Drawing.Point(6, 115);
            this.phonenumber.Name = "phonenumber";
            this.phonenumber.Size = new System.Drawing.Size(116, 17);
            this.phonenumber.TabIndex = 5;
            this.phonenumber.Text = "PHONE NUMBER";
            // 
            // rdcashondelivery
            // 
            this.rdcashondelivery.AutoSize = true;
            this.rdcashondelivery.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdcashondelivery.Location = new System.Drawing.Point(90, 161);
            this.rdcashondelivery.Name = "rdcashondelivery";
            this.rdcashondelivery.Size = new System.Drawing.Size(129, 21);
            this.rdcashondelivery.TabIndex = 2;
            this.rdcashondelivery.TabStop = true;
            this.rdcashondelivery.Text = "Cash on Delivery";
            this.rdcashondelivery.UseVisualStyleBackColor = true;
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(128, 70);
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(186, 20);
            this.txtaddress.TabIndex = 3;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(128, 28);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(186, 24);
            this.txtname.TabIndex = 2;
            // 
            // ADDRESSLABEL
            // 
            this.ADDRESSLABEL.AutoSize = true;
            this.ADDRESSLABEL.Location = new System.Drawing.Point(31, 70);
            this.ADDRESSLABEL.Name = "ADDRESSLABEL";
            this.ADDRESSLABEL.Size = new System.Drawing.Size(69, 17);
            this.ADDRESSLABEL.TabIndex = 1;
            this.ADDRESSLABEL.Text = "ADDRESS";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.namelabel.Location = new System.Drawing.Point(52, 35);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(48, 17);
            this.namelabel.TabIndex = 0;
            this.namelabel.Text = "NAME";
            // 
            // buttonsubmit
            // 
            this.buttonsubmit.BackColor = System.Drawing.Color.Gold;
            this.buttonsubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonsubmit.Font = new System.Drawing.Font("Microsoft JhengHei UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonsubmit.ForeColor = System.Drawing.Color.White;
            this.buttonsubmit.Location = new System.Drawing.Point(444, 269);
            this.buttonsubmit.Name = "buttonsubmit";
            this.buttonsubmit.Size = new System.Drawing.Size(163, 30);
            this.buttonsubmit.TabIndex = 5;
            this.buttonsubmit.Text = "Submit";
            this.buttonsubmit.UseVisualStyleBackColor = false;
            this.buttonsubmit.Click += new System.EventHandler(this.buttonsubmit_Click);
            // 
            // Delivery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(635, 326);
            this.Controls.Add(this.buttonsubmit);
            this.Controls.Add(this.groupBox1);
            this.Name = "Delivery";
            this.ShowIcon = false;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.ListBox listareas;
        private System.Windows.Forms.RadioButton rdcreditcard;
        private System.Windows.Forms.Label phonenumber;
        private System.Windows.Forms.RadioButton rdcashondelivery;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label ADDRESSLABEL;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.Button buttonsubmit;
    }
}