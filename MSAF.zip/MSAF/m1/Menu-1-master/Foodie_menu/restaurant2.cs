﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Foodie_menu
{
    public partial class restaurant2 : UserControl
    {
       
        public restaurant2()
        {
            InitializeComponent();
            myCart2 obj = new myCart2();
            obj.review_updater();
            exclusive21.BringToFront();
            exclusive21.work();
            movePanel(exclusive2_button);
        }

        public void movePanel(Control btn)
        {
            slide_panel.Width = btn.Width;
            slide_panel.Left = btn.Left;

        }
        private void restaurant2_Load(object sender, EventArgs e)
        {


            myCart2 obj = new myCart2();
            obj.review_updater();

        }

        private void home2_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            favorite21.Hide();
            movePanel(home2_button);
            Form2 f = new Form2();
            f.Show();
            myCart2 c = new myCart2();
            c.savingDataa();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            myCart2 obj = new myCart2();
            obj.review_updater();
            exclusive21.BringToFront();
            exclusive21.work();
            movePanel(exclusive2_button);

        }

        private void homeFood2_button_Click(object sender, EventArgs e)
        {
            myCart2 obj = new myCart2();
            obj.review_updater();
            movePanel(homeFood2_button);
            homeFood21.BringToFront();
            homeFood21.work();
        }

        private void favorites2_button_Click(object sender, EventArgs e)
        {
            favorite21.BringToFront();
            favorite21.work();
            movePanel(favorites2_button);
        }

        private void review2_button_Click(object sender, EventArgs e)
        {
            review21.BringToFront();
            review21.work();
            movePanel(review2_button);
        }

        

        

       

        private void close_button_Click(object sender, EventArgs e)
        {
            myCart2 obj = new myCart2();
            obj.savingDataa();
            Application.Exit();
        }

        private void minimize_button_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cart21.BringToFront();
            cart21.work();
        }

        private void review21_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           
        }

        private void cart_button_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            CR c = new CR();
            c.Show();
        }
    }
}
