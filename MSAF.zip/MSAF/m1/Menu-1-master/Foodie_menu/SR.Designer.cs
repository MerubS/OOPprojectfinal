﻿namespace Foodie_menu
{
    partial class SR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.restaurant21 = new Foodie_menu.restaurant2();
            this.SuspendLayout();
            // 
            // restaurant21
            // 
            this.restaurant21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.restaurant21.ForeColor = System.Drawing.Color.White;
            this.restaurant21.Location = new System.Drawing.Point(0, 0);
            this.restaurant21.Margin = new System.Windows.Forms.Padding(0);
            this.restaurant21.Name = "restaurant21";
            this.restaurant21.Size = new System.Drawing.Size(941, 539);
            this.restaurant21.TabIndex = 3;
            this.restaurant21.Load += new System.EventHandler(this.restaurant21_Load);
            // 
            // SR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(941, 539);
            this.Controls.Add(this.restaurant21);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SR";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion
        private restaurant2 restaurant21;
    }
}