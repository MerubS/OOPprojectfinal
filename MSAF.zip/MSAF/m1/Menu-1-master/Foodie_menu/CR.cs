﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class CR : Form
    {
        public CR()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string text = listBox1.GetItemText(listBox1.SelectedItem);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your Message has been sent to the rider");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please Call us at 090078601");
        }
    }
}
