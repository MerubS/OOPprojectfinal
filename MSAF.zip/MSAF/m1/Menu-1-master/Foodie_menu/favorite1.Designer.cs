﻿namespace Foodie_menu
{
    partial class favorite1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.flag_1 = new System.Windows.Forms.Label();
            this.addToCart_button = new System.Windows.Forms.Button();
            this.item_picture = new System.Windows.Forms.PictureBox();
            this.favoriteList = new System.Windows.Forms.ListBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.item_picture)).BeginInit();
            this.SuspendLayout();
            // 
            // flag_1
            // 
            this.flag_1.AutoSize = true;
            this.flag_1.BackColor = System.Drawing.Color.Transparent;
            this.flag_1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_1.ForeColor = System.Drawing.Color.Red;
            this.flag_1.Location = new System.Drawing.Point(165, 353);
            this.flag_1.Name = "flag_1";
            this.flag_1.Size = new System.Drawing.Size(174, 20);
            this.flag_1.TabIndex = 4;
            this.flag_1.Text = "Item Added To Cart!!";
            this.flag_1.Visible = false;
            this.flag_1.Click += new System.EventHandler(this.flag_1_Click);
            // 
            // addToCart_button
            // 
            this.addToCart_button.BackColor = System.Drawing.Color.Gold;
            this.addToCart_button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.addToCart_button.FlatAppearance.BorderSize = 0;
            this.addToCart_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addToCart_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addToCart_button.ForeColor = System.Drawing.Color.White;
            this.addToCart_button.Location = new System.Drawing.Point(256, 407);
            this.addToCart_button.Name = "addToCart_button";
            this.addToCart_button.Size = new System.Drawing.Size(141, 33);
            this.addToCart_button.TabIndex = 3;
            this.addToCart_button.Text = "Add To Cart";
            this.addToCart_button.UseVisualStyleBackColor = false;
            this.addToCart_button.Click += new System.EventHandler(this.remove_item_Click);
            // 
            // item_picture
            // 
            this.item_picture.Location = new System.Drawing.Point(0, 0);
            this.item_picture.Name = "item_picture";
            this.item_picture.Size = new System.Drawing.Size(406, 306);
            this.item_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.item_picture.TabIndex = 1;
            this.item_picture.TabStop = false;
            this.item_picture.Visible = false;
            this.item_picture.Click += new System.EventHandler(this.item_picture_Click);
            // 
            // favoriteList
            // 
            this.favoriteList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.favoriteList.BackColor = System.Drawing.Color.Gold;
            this.favoriteList.Font = new System.Drawing.Font("Microsoft JhengHei UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.favoriteList.ForeColor = System.Drawing.Color.White;
            this.favoriteList.FormattingEnabled = true;
            this.favoriteList.ItemHeight = 19;
            this.favoriteList.Location = new System.Drawing.Point(403, 0);
            this.favoriteList.Name = "favoriteList";
            this.favoriteList.Size = new System.Drawing.Size(609, 536);
            this.favoriteList.TabIndex = 0;
            this.favoriteList.SelectedIndexChanged += new System.EventHandler(this.favoriteList_SelectedIndexChanged);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gold;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(109, 407);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(141, 33);
            this.button1.TabIndex = 5;
            this.button1.Text = "Remove";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // favorite1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.flag_1);
            this.Controls.Add(this.addToCart_button);
            this.Controls.Add(this.favoriteList);
            this.Controls.Add(this.item_picture);
            this.Name = "favorite1";
            this.Size = new System.Drawing.Size(941, 476);
            ((System.ComponentModel.ISupportInitialize)(this.item_picture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox favoriteList;
        private System.Windows.Forms.Button addToCart_button;
        private System.Windows.Forms.Label flag_1;
        private System.Windows.Forms.PictureBox item_picture;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button1;
    }
}
