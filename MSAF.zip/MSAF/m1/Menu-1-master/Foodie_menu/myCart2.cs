﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.Serialization.Formatters.Binary;
namespace Foodie_menu { 

           ///////////////////////////      Cart For Ithaa Chalet        ///////////////////
    public class myCart2
    {

        public static string[] items_2 = new string[21];      // Array to store items in cart (max 20 items)
        public static int index1_2 = 0;                       // Variable to store number of items in cart (array index based)

        public static string[] favorites_2 = new string[11];  // Array to store items in favorites (max 10 items)
        public static int index2_2 = 0;                       // Variable to store numbert of favorite items( array index based)
        public static int bill_2 = 0;                         // Variable to store bill amount

        private static int[] myReview_2 = new int[10];        // Int Array to store customer Rating ( 1 to 5)
        private static int[] Reviews_2 = new int[10];         // Int Array to store universal Rating (SUM)

        static int customers;                                 // variable to store number of customer who submitted reviews 
        static int customer_id;                               // User ID from database
        string coupon;                                        // Stores the valid coupon code



        public myCart2() { }// Constructor---- DEFAULT



        public myCart2(string[] fav, int[] myRev,int id)       // Constructor To initialiaze favorites and reviews from database of customer
        {
            favorites_2 = fav;
            myReview_2 = myRev;
            customer_id = id;

            foreach (string x in favorites_2)
            {
                if (x == " ")
                {
                    continue;
                }

                if (x == "Latte" || x == "Cappuccino" || x == "Cortado" || x == "Mocha" || x == "Americano" || x == "Lungo" || x == "Black Coffee" || x == "Espresso" || x == "Tea" || x == "Mazagran")
                {
                    index2_2++;
                }
            }
            index2_2++;

            if (index2_2 == 1) { index2_2 = 0; }

        }

        
        public void review_updater()                              // SYNCS universal reviews to Review array
        {                   
            using (StreamReader file = new StreamReader("Review_2.txt"))
            {
                for (int i = 0; i < 10; i++)
                    Reviews_2[i] = int.Parse(file.ReadLine());

                customers = int.Parse(file.ReadLine());             // Gets number of customers who submitted reviews
            }
        }

        public void savingDataa()                  // Updates arrays of favorites and reviews when changes are made by customer
        {
            
            BinaryFormatter f = new BinaryFormatter();
            MemoryStream ms = new MemoryStream();
            f.Serialize(ms, favorites_2);
            byte[] bi = ms.ToArray();
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\zahid\source\repos\Project.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            SqlCommand comm = new SqlCommand();
            comm.CommandText = "update [useraccount] SET ifavourites = @fav where UID = @val";
            comm.Connection = con;
            comm.Parameters.AddWithValue("@val", customer_id);
            comm.Parameters.AddWithValue("@fav", bi);
            int i = comm.ExecuteNonQuery();
            if (i > 0)
            {
                Console.WriteLine("Favorites updated for Ithaa Chalet");
            }
                con.Close();
                MemoryStream mb = new MemoryStream();
                f.Serialize(mb, myReview_2);
                byte[] by = mb.ToArray();
                con.Open();
                comm.CommandText = "update [useraccount] SET ireview = @rev where UID = @val";
                comm.Connection = con;
                comm.Parameters.AddWithValue("@rev", by);
                int m = comm.ExecuteNonQuery();
                if (m > 0)
                {
                Console.WriteLine("Reviews updated for Ithaa Chalet");
            }
                con.Close();
           
        }
        public void file_updater()                      // Updates file contents whenever a review is submitted
        {
            customers++;

            for (int i = 0; i < 10; i++)
            {
                Reviews_2[i] += myReview_2[i];
            }

            using (StreamWriter file = new StreamWriter("Review_2.txt"))
            {
                foreach (var x in Reviews_2)
                    file.WriteLine(x.ToString());


                file.WriteLine(customers.ToString());
            }
        }




        ///////////////// Setter / Getters For Item Rating and etc // /////////////

        public void SET_myReview(int index, int rating)
        {    /// Sets rating for an item in index sequence
            myReview_2[index] = rating;
        }

        public int GET_myReview(int index)                /// Gets customer rating for an item in index sequence
        {
            return myReview_2[index];
        }

        public int GET_Reviews(int index)                /// Gets Universal Rating for an item in index sequence
        {

            try
            {
                int rating = Reviews_2[index] / customers;   /// Performs average calculation
                return rating;
            }
            catch
            {
                return 1;
            }

        }

        public void couponset(string a)       // Setter For Coupon
        {
            coupon = a;
        }

        public string getcoupon()               // Getter For Coupon Code
        {
            return coupon;
        }


        public int _bill
        {                     // Getter Function For Bill
            get { return bill_2; }
        }



        /////////////////////   Function To Remove Item From Cart ///////////////////
        public void removeItem(string item)                 //// Item To be deleted gets passed as parameter ////
        {
            int k = 0;

            foreach (string s in items_2)
            {
                if (item == s)
                {

                    switch (item)                    ///// Remove Deleted item Price From Bill//////////
                    {
                        case "Latte":
                            bill_2 -= 250; break;
                        case "Cappuccino":
                            bill_2 -= 300; break;
                        case "Cortado":
                            bill_2 -= 200; break;
                        case "Mocha":
                            bill_2 -= 350; break;
                        case "Americano":
                            bill_2 -= 300; break;
                        case "Lungo":
                            bill_2 -= 150; break;
                        case "Black Coffee":
                            bill_2 -= 100; break;
                        case "Espresso":
                            bill_2 -= 200; break;
                        case "Tea":
                            bill_2 -= 60; break;
                        case "Mazagran":
                            bill_2 -= 180; break;

                        default: MessageBox.Show("Item Not Found"); break;
                    }


                    break;
                }
                k++;
            }

            while (k < index1_2)        ////// Shifts elements in the array after an item is deleted
            {

                items_2[k] = items_2[k + 1];
                k++;
            }
            index1_2--;                         //// Reduces index as one item is removed
        }



        //////////////////////// Function To Remove an item From favorites ////////////////////
        ///
        public void removeFavorite(string fav)            //// Items that needs to be deleted gets passed as a paramater

        {

            int k = 0;
            foreach (string favo in favorites_2)
            {

                if (fav == favo)                 //// Finds the index of the item to be removed
                {
                    break;
                }
                k++;

            }

            while (k < index2_2)              //// Shifts items after an item gets deleted
            {
                favorites_2[k] = favorites_2[k + 1];
                k++;
            }

            index2_2--;                        // Reduces array index as an item gets removed

        }


        /////////////////////// Function To add item in Cart ///////////////////
        ///
        public void addItem(String item)      //// Item to add gets passed as a string parameter
        {

            if (index1_2 < 20)               // Checks that items in cart are no more than 20
            {

                items_2[index1_2++] = item;

                switch (item)               /// Adds the price of item in the bill
                {
                    case "Latte":
                        bill_2 += 250; break;
                    case "Cappuccino":
                        bill_2 += 300; break;
                    case "Cortado":
                        bill_2 += 200; break;
                    case "Mocha":
                        bill_2 += 350; break;
                    case "Americano":
                        bill_2 += 300; break;
                    case "Lungo":
                        bill_2 += 150; break;
                    case "Black Coffee":
                        bill_2 += 100; break;
                    case "Espresso":
                        bill_2 += 200; break;
                    case "Tea":
                        bill_2 += 60; break;
                    case "Mazagran":
                        bill_2 += 180; break;

                    default: MessageBox.Show("Item Not Found"); break;
                }
            }
            else              /// If items are more than 20 a Message is displayed indicating "cart is full"
            {
                MessageBox.Show("You Can't Add More Than 20 Items To Your Cart", "Cart Full", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }


        //////////////////////// Function to add an item to favorites /////////////////////
        ///

        public void addFavorite(string fav)       /// Item to be deleted gets passed as string parameter
        {
            if (index2_2 < 10)                       /// No more than 10 items can be added to favorites
            {
                bool x = true;                       ///  Flag to indicate if item can be added or not (duplication check)
                foreach (string favo in favorites_2)
                {
                    if (fav == favo)        // Checks that items in favorites dont get duplictaed
                    {
                        x = false;
                        break;
                    }
                    else
                    {
                        x = true;              // Used to grants permission to add item in favorites
                    }
                }
                if (x)
                {
                    favorites_2[index2_2++] = fav;           // Adds item to favorites

                }
            }

            else             /// A message gets displayed indicating " MAX 10 items can be added to favorites
            {
                MessageBox.Show("You Can't Add More Than 10 Items To Your Favorites", "Favorites", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }



    }

}

