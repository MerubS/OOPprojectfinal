﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Windows.Forms.VisualStyles;

namespace Foodie_menu
{
    public partial class favorite1 : UserControl
    {

        myCart obj = new myCart();
        public favorite1()
        {
            InitializeComponent();
        }

        private void flag_1_Click(object sender, EventArgs e)
        {

        }

        public void work()             // Updates UI whenever favorite tab is clicked
        {
            favoriteList.Items.Clear();
            foreach(string x in myCart.favorites)
            
            {
                if ( x != null)
                favoriteList.Items.Add(x);
            }
            addToCart_button.Visible = true;

        }



        private void favoriteList_SelectedIndexChanged(object sender, EventArgs e)       // Changes image for item
        {
            item_picture.Visible = true;
            if ((string)favoriteList.SelectedItem == "Pizza") { item_picture.Image = Resource1.pizza;}
            else if ((string)favoriteList.SelectedItem == "Pasta") { item_picture.Image = Resource1.pasta; }
            else if ((string)favoriteList.SelectedItem == "Sandwhich") { item_picture.Image = Resource1.sandwhich;}
            else if ((string)favoriteList.SelectedItem == "Burger") { item_picture.Image = Resource1.burger;}
            else if ((string)favoriteList.SelectedItem == "French Fries") { item_picture.Image = Resource1.fries;}
            else if ((string)favoriteList.SelectedItem == "Pulao") { item_picture.Image = Resource1.pulao; }
            else if ((string)favoriteList.SelectedItem == "Daal Mix") { item_picture.Image = Resource1.daal;}
            else if ((string)favoriteList.SelectedItem == "Chicken Roast") { item_picture.Image = Resource1.roast; }
            else if ((string)favoriteList.SelectedItem == "Mutton Karahi") { item_picture.Image = Resource1.karahi; }
            else if ((string)favoriteList.SelectedItem == "Haleem") { item_picture.Image = Resource1.haleem; }
            else { item_picture.Visible = false; }
        }       
        

       

        private void remove_item_Click(object sender, EventArgs e)    // adds selected item to cart
        {
            if (favoriteList.SelectedItem == null)
            {
                MessageBox.Show("Select An Item", "Favorites", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                obj.addItem((string)favoriteList.SelectedItem);
                flag_1.Visible = true;
                timer1.Start();
            }   
        }

        private void timer1_Tick(object sender, EventArgs e)   // timer for labels
        {
            if (flag_1.Visible)
            {
                flag_1.Visible = false;
                timer1.Stop();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (favoriteList.SelectedItem != null)
            {
                obj.removeFavorite(favoriteList.SelectedItem.ToString());
                favoriteList.Items.Remove(favoriteList.SelectedItem);
            }
            else
            {
                MessageBox.Show("Please Select An Item To Remove", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void item_picture_Click(object sender, EventArgs e)
        {

        }
    }
}
