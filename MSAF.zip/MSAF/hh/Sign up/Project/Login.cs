﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.Data.SqlClient;
using System.IO;
using System.Net.Http.Headers;

namespace Project
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            groupbox2.Visible = false;
            First.Visible = true;


        }





        private void Form1_Load(object sender, EventArgs e)
        {

        }



        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void top1_Load(object sender, EventArgs e)
        {

        }

        private void Logii_Click(object sender, EventArgs e)
        {
            First.Show();
            groupbox2.Hide();

        }




         
                                                                // Properties for textbox //

        private void username_TextChanged(object sender, EventArgs e)
        {

        }

        private void username_Enter(object sender, EventArgs e)
        {
            if (username.Text == "Username")
            {
                username.Text = "";
                username.ForeColor = Color.Black;
            }
        }

        private void pass_Enter(object sender, EventArgs e)
        {
            if (pass.Text == "Password")
            {
                pass.Text = "";
                pass.ForeColor = Color.Black;
            }
        }

        private void username_Leave(object sender, EventArgs e)
        {
            if (username.Text == "")
            {
                username.Text = "Username";
                username.ForeColor = Color.Silver;
            }
        }

        private void pass_Leave(object sender, EventArgs e)
        {
            if (pass.Text == "")
            {
                pass.Text = "Password";
                pass.ForeColor = Color.Silver;
            }
        }

        private void username2_Enter(object sender, EventArgs e)
        {
            if (username2.Text == "Username")
            {
                username2.Text = "";
                username2.ForeColor = Color.Black;
            }
        }

        private void username2_Leave(object sender, EventArgs e)
        {
            if (username2.Text == "")
            {
                username2.Text = "Username";
                username2.ForeColor = Color.Silver;
            }
        }

        private void email_Enter(object sender, EventArgs e)
        {
            if (email.Text == "someone@example.com")
            {
                email.Text = "";
                email.ForeColor = Color.Black;
            }
        }

        private void email_Leave(object sender, EventArgs e)
        {
            if (email.Text == "")
            {
                email.Text = "someone@example.com";
                email.ForeColor = Color.Silver;
            }
        }

        private void pass2_Enter(object sender, EventArgs e)
        {
            if (pass2.Text == "Password")
            {
                pass2.Text = "";
                pass2.ForeColor = Color.Black;
            }
        }

        private void pass2_Leave(object sender, EventArgs e)
        {
            if (pass2.Text == "")
            {
                pass2.Text = "Password";
                pass2.ForeColor = Color.Silver;
            }
        }

        private void cpass_Enter(object sender, EventArgs e)
        {
            if (cpass.Text == "Confirm Password")
            {
                cpass.Text = "";
                cpass.ForeColor = Color.Black;
            }
        }

        private void cpass_Leave(object sender, EventArgs e)
        {
            if (cpass.Text == "")
            {
                cpass.Text = "Confirm Password";
                cpass.ForeColor = Color.Silver;
            }
        }

        private void address_Enter(object sender, EventArgs e)
        {
            if (address.Text == "Address")
            {
                address.Text = "";
                address.ForeColor = Color.Black;
            }
        }

        private void address_Leave(object sender, EventArgs e)
        {
            if (address.Text == "")
            {
                address.Text = "Address";
                address.ForeColor = Color.Silver;
            }
        }

        private void contact_Enter(object sender, EventArgs e)
        {
            if (contact.Text == "Contact")
            {
                contact.Text = "";
                contact.ForeColor = Color.Black;
            }
        }

        private void contact_Leave(object sender, EventArgs e)
        {
            if (contact.Text == "")
            {
                contact.Text = "Contact";
                contact.ForeColor = Color.Silver;
            }
        }

        private void Signn_Click(object sender, EventArgs e)
        {

            groupbox2.Show();

        }
                                                        
                                                                     // Sign Up //
        private void Back_Click(object sender, EventArgs e)                          
        {
            if (pass2.Text == cpass.Text)
            {
                int flag =0;
                string[] ffav = { " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " " };
                string[] ifav = { " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " " };
                int[] freview = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }; 
                int[] ireview = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\zahid\source\repos\Project.mdf;Integrated Security=True;Connect Timeout=30");
                con.Open();
                SqlCommand comm = new SqlCommand();
                comm.CommandText = "insert into [userinfo] values (@username,@password)";
                comm.Connection = con;
                comm.Parameters.AddWithValue("@username", username2.Text);
                comm.Parameters.AddWithValue("@password", pass2.Text);
                int i = comm.ExecuteNonQuery();

                MemoryStream ms = new MemoryStream();
                BinaryFormatter fs = new BinaryFormatter();
                fs.Serialize(ms, ffav);
                byte[] bs = ms.ToArray();

                MemoryStream me = new MemoryStream();
                BinaryFormatter fe = new BinaryFormatter();
                fe.Serialize(me, ifav);
                byte[] be = me.ToArray();

                MemoryStream mi = new MemoryStream();
                BinaryFormatter fi = new BinaryFormatter();
                fi.Serialize(mi, freview);
                byte[] bi = mi.ToArray();

                MemoryStream mu = new MemoryStream();
                BinaryFormatter fu = new BinaryFormatter();
                fu.Serialize(mu, ireview);
                byte[] bu = mu.ToArray();
                SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "insert into [useraccount] values(@Address,@Email,@Contact,@ffavourites,@ifavourites,@freview,@ireview)";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@Address", address.Text);
                cmd.Parameters.AddWithValue("@Email", email.Text);
                cmd.Parameters.AddWithValue("@Contact", contact.Text);
                cmd.Parameters.AddWithValue("@ffavourites", bs);
                cmd.Parameters.AddWithValue("@ifavourites", be);
                cmd.Parameters.AddWithValue("@freview", bi);
                cmd.Parameters.AddWithValue("@ireview", bu);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {
                    Console.WriteLine("Information inserted");
                    flag++;
                    Foodie_menu.Form2 f = new Foodie_menu.Form2();
                    f.Show();
                    this.Hide();
                }

               

                
            }

            else
            {
                MessageBox.Show("Passwords are not same");
            }



        }

                                                         // Generating Coupon //

        public string RandomString(int size, bool lowerCase)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (lowerCase)
                return builder.ToString().ToLower();
            return builder.ToString();
        }
        public int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        public string Randomcoupon()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(RandomString(2, true));
            builder.Append(RandomNumber(10, 99));
            builder.Append(RandomString(2, false));
            return builder.ToString();
        }
                           

                                                        //  Log In  //

        private void Lsubmit_Click(object sender, EventArgs e)                           
        {
            int value;
            string que = "Select * From userinfo where Username= '" + username.Text + "' and Password = '" + pass.Text + "'";
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\zahid\source\repos\Project.mdf;Integrated Security=True;Connect Timeout=30");
            SqlCommand comm = new SqlCommand(que, con);
            con.Open();
            SqlDataReader dr = comm.ExecuteReader();

            if (dr.Read())
            {
                value = Convert.ToInt32(dr["ID"]);

                string[] ffav = new string[11];
                string[] ifav = new string[11];
                int[] freview = new int[10];
                int[] ireview = new int[10];
                con.Close();
                this.Hide();
                Foodie_menu.Form2 f = new Foodie_menu.Form2();
                f.Show();
                BinaryFormatter formatter = new BinaryFormatter();
                string query = "select * from useraccount where UID = @val";

                using (SqlCommand command = new SqlCommand(query, con))

                {
                    command.Parameters.AddWithValue("@val", value);
                    con.Open();
                    command.ExecuteNonQuery();


                    var rd = command.ExecuteReader();

                    if (rd.Read())
                    {

                        var blob = new Byte[(rd.GetBytes(3, 0, null, 0, int.MaxValue))];     // Foodie Hub Favourites
                        rd.GetBytes(3, 0, blob, 0, blob.Length);

                        MemoryStream ms = new MemoryStream(blob);
                        ms.Position = 0;
                        ffav = (string[])formatter.Deserialize(ms);

                        blob = new Byte[(rd.GetBytes(4, 0, null, 0, int.MaxValue))];     // ithaa chalet Favourites
                        rd.GetBytes(4, 0, blob, 0, blob.Length);
                        ms = new MemoryStream(blob);
                        ms.Position = 0;
                        ifav = (string[])formatter.Deserialize(ms);

                        blob = new Byte[(rd.GetBytes(5, 0, null, 0, int.MaxValue))];     // Foodie Hub Reviews
                        rd.GetBytes(5, 0, blob, 0, blob.Length);
                        ms = new MemoryStream(blob);
                        ms.Position = 0;
                        freview = (int[])formatter.Deserialize(ms);

                        blob = new Byte[(rd.GetBytes(6, 0, null, 0, int.MaxValue))];     // ithaa chalet Reviews
                        rd.GetBytes(6, 0, blob, 0, blob.Length);
                        ms = new MemoryStream(blob);
                        ms.Position = 0;
                        ireview = (int[])formatter.Deserialize(ms);
                    }

                    
                }



                //string[] ffav = { "Pizza","Pasta"," ", " " ," "," "," "," ", " ", " "," "};
                //string[] ifav = { "Lungo", "Mazagran", "Black Coffee", " ", " ", " ", "", " ", " ", " ", " " };
                //int[] freview = { 1, 2, 3, 4, 5, 5, 4, 3, 2, 1 };
                //int[] ireview = { 1, 2, 3, 4, 5, 5, 4, 3, 2, 1 };



                Foodie_menu.myCart c = new Foodie_menu.myCart(ffav, freview, value);
                Foodie_menu.myCart2 cm = new Foodie_menu.myCart2(ifav, ireview, value);
                string coupon = Randomcoupon();
                c.couponset(coupon);
                cm.couponset(coupon);

            }
            else
            {
                MessageBox.Show("Password or Username is incorrect");
            }
        }
    } }

